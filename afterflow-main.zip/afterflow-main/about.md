# Afterflow

by prsevend

a predictive input cheat that fixes your early clicks and makes them accurate.

built for **geometry dash 2.2** (gd 2.2081, geode 5.11.2) on windows, macos, android and ios. **f6** cycles stages anywhere. **f9** opens a custom in-game control panel with stage controls, a live log, copy log and a terminal shortcut. on mobile, a draggable **AF** button opens the same panel. both desktop keys are geode keybinds, so you can rebind them in mod settings or the keybinds popup.

## what it does

geometry dash runs physics at a fixed **240 ticks per second**. afterflow keeps a hidden ghost player and for every press or release it tests the input at its current tick and at delays of 1..n ticks. if pressing now would kill you but a delayed version survives, the input is held back and delivered on the surviving tick. the same check runs for releases so early clicks and early let-gos can both be corrected.

the prediction understands cube, ball, ufo, spider, swing, wave, robot and ship movement plus orbs, pads, gravity portals, size portals, speed portals and click between frames' mid tick clicks. it never changes the real level state since ghosts are simulated in a detached layer and every object they touch is restored afterwards.

## controls

afterflow uses geode keybind settings. open **mod settings -> afterflow** (or geode's **keybinds** popup) to change them.

| Setting | Default | Where |
| ------- | ------- | ----- |
| Cycle Stage | F6 | anywhere |
| Control Panel | F9 | everywhere |

the first launch shows a one time note with the current bindings and a shortcut to mod settings. a saved flag records that it was seen so it does not come back.

on mobile the panel key is replaced by the floating **AF** button. drag it anywhere to move it; tap it to open the panel. the position is remembered between sessions.

## control panel

press **f9** (or your bound panel key) to open the panel. while it is open the game pauses so you can change settings without dying. press **f9** again, click **CLOSE**, click the **X**, or click outside the panel to resume.

the panel shows:

- the current stage with previous/next arrows and numbered stage pills for direct selection
- a live log of recent predictions, saved inputs and stage changes
- **COPY** to copy the recent log to the clipboard
- **TERMINAL** to open or close the afterflow log window (desktop only, when **enable terminal** is on)
- **CLOSE** to dismiss the panel

## ui customization

open **mod settings -> afterflow -> ui customization** to change the panel appearance. changes apply live while the panel is open.

| Setting | Default | Range |
| ------- | ------- | ----- |
| Primary Color | `#7C4DFF` | any color |
| Secondary Color | `#FFFFFF` | any color |
| Panel Scale | `1.0` | `0.7` - `1.3` |
| Font Scale | `1.0` | `0.8` - `1.5` |

the panel uses bundled Sora fonts. if the font files are missing it falls back to geometry dash's `bigFont.fnt`.

## stages

press **f6** (or your bound cycle stage key) anywhere to cycle. the stage is remembered across sessions. outside a level the selected stage is written to the terminal log. the key also works while the panel or terminal is open.

| Stage | All modes | Wave |
| ----- | --------- | ---- |
| 1 | 2 ticks | 2 ticks |
| 2 | 4 ticks | 4 ticks |
| 3 | 8 ticks | 8 ticks |
| 4 | 16 ticks | 8 ticks |
| 5 | 24 ticks | 12 ticks |
| 6 | 32 ticks | 16 ticks |
| 7 | 40 ticks | 20 ticks |
| 8 | off - 100% raw input | off |

at 60 fps one frame is 4 ticks so 4 ticks is `1.0f @ 60fps` and 16 ticks is `4.0f @ 60fps`.

## terminal

the **TERMINAL** button in the control panel opens the afterflow log window. the **enable terminal** setting shows or hides that button; it defaults to on. the terminal is not available on mobile.

the game runs as a windows process under proton so it cannot start a linux program directly. afterflow writes a live log to `/dev/shm/afterflow-<user>/terminal.log` (where `<user>` is your linux username) and drops a trigger file at `/dev/shm/afterflow-<user>/open-kitty`. `/dev/shm` is memory-backed, so the log and runtime files disappear on reboot; if `/dev/shm` is unavailable afterflow falls back to `/tmp/afterflow-<user>`. a small systemd user service watches the trigger and toggles the real **kitty** window on the host while tailing that log.

on native windows the terminal button launches **powershell** directly with a small winforms log viewer (title `Afterflow`). the log is a transient `%TEMP%\afterflow-terminal-<pid>.log` opened with delete-on-close, so windows removes it when the game exits. the viewer stays on top and tails the log. the systemd/kitty path is only used under proton.

if the viewer does not appear, afterflow writes the powershell error to the terminal log and the geode console. if the game is in exclusive fullscreen, switch to borderless or windowed so the viewer can be raised above it.

on native macos the terminal button opens **terminal.app** with a bash log viewer (title `Afterflow`) that tails `$TMPDIR/afterflow-<user>/terminal.log`. the runtime directory is per-user and temporary, and no service or extra dependency is needed.

the terminal captures **f6** and **f9** so key escape sequences are not echoed. f6 forwards a stage cycle request to the game and f9 closes the terminal window. on linux the kitty window maps f6 directly to a cycle helper, and on windows the log viewer handles f6 itself. if you rebind the settings the in-game keys change but the terminal's capture keys stay f6/f9. the same capture works in the native windows and macos terminals.

the service is included as `afterflow-terminal-watch.sh` + `afterflow-terminal.service`:

```sh
install -Dm755 afterflow-terminal-watch.sh ~/.local/bin/afterflow-terminal-watch.sh
mkdir -p ~/.config/systemd/user
cp afterflow-terminal.service ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user enable --now afterflow-terminal.service
```

the service starts with your user session and reads the running compositor environment itself (hyprland, sway, niri, kde, gnome, or x11), so you do not need to import wayland variables manually. after updating, re-copy both the script and the unit, then run `systemctl --user daemon-reload`, `systemctl --user enable afterflow-terminal.service`, and `systemctl --user restart afterflow-terminal.service`. if the terminal button does nothing, check `/dev/shm/afterflow-<user>/watch.log`, `/dev/shm/afterflow-<user>/kitty.log`, and `journalctl --user -u afterflow-terminal.service`; `watch.log` records the detected wayland and display values.

requires `kitty` on linux/proton. native windows uses powershell and needs no service. on hyprland the service also applies a floating centered window rule and raises the window above the game. on other compositors the log window still opens but placement is left to the window manager.

## build

you need geode sdk 5.11.2, cmake 3.29+ and the 2.2081 bindings. on windows, use clang-cl (the visual studio clang toolset or llvm) and ninja for large translation units. if `build/` was previously configured with msvc, delete it first so cmake picks up clang-cl.

```sh
# linux cross compiling a windows mod
export GEODE_SDK=/path/to/geode-sdk
export GEODE_BINDINGS_REPO_PATH=/path/to/geode-bindings   # only needed for the 2.2081 binding fixes
geode build -p windows

# windows (clang-cl + ninja)
set GEODE_SDK=C:\path\to\geode-sdk
set CC=clang-cl
set CXX=clang-cl
geode build --ninja

# macos (native, builds arm64 and x86_64 by default)
export GEODE_SDK=/path/to/geode-sdk
geode build

# android (requires the android ndk)
export GEODE_SDK=/path/to/geode-sdk
geode build -p android
```

the packaged mod ends up in `build-win/` when cross compiling from linux (`build/` on windows and macos) and it also gets copied into the game's `geode/mods` folder automatically.

## installation

copy the resulting .geode file into geometry dash's geode/mods folder and restart the game. enable **afterflow** in the geode mod list. the defaults work out of the box so you can rebind the keys in mod settings if you want different ones.

## credits

dynamic mod
whitechocolate
click before frames

lucide.dev for icon

## warnings

this is a cheat. it changes input timing so your runs are not legit. dont use it on rated levels or leaderboard submissions or anything you want to claim as legit. some levels and lists have input buffer or macro detectors so you can get flagged.
